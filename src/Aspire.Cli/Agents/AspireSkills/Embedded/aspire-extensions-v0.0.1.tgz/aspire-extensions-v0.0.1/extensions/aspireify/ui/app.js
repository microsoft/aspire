"use strict";

const EDGE_LABELS = {
    reference: "references",
    waitFor: "waits for",
    parent: "child of",
};

const SVG_NS = "http://www.w3.org/2000/svg";

const elements = {
    body: document.body,
    statusLine: document.getElementById("status-line"),
    apphostControl: document.getElementById("apphost-control"),
    apphostStyle: document.getElementById("apphost-style"),
    apphostValue: document.getElementById("apphost-value"),
    rescan: document.getElementById("rescan"),
    scanActionLabel: document.getElementById("scan-action-label"),
    scan: document.getElementById("scan"),
    idle: document.getElementById("idle"),
    idleTitle: document.getElementById("idle-title"),
    idleDetail: document.getElementById("idle-detail"),
    skeleton: document.getElementById("skeleton"),
    snapshot: document.getElementById("snapshot"),
    planPending: document.getElementById("plan-pending"),
    planContent: document.getElementById("plan-content"),
    addInfrastructure: document.getElementById("add-infrastructure"),
    graphPanel: document.getElementById("graph-panel"),
    graphScroll: document.getElementById("graph-scroll"),
    graph: document.getElementById("dependency-graph"),
    addConnection: document.getElementById("add-connection"),
    actionFooter: document.getElementById("action-footer"),
    footerNote: document.getElementById("footer-note"),
    confirm: document.getElementById("confirm"),
    error: document.getElementById("error"),
    errorMessage: document.getElementById("error-message"),
    retry: document.getElementById("retry"),
    resourceDialog: document.getElementById("resource-dialog"),
    resourceForm: document.getElementById("resource-form"),
    resourceId: document.getElementById("resource-id"),
    resourceName: document.getElementById("resource-name"),
    resourceType: document.getElementById("resource-type"),
    resourceDialogDetail: document.getElementById("resource-dialog-detail"),
    defaultsField: document.getElementById("defaults-field"),
    resourceDefaults: document.getElementById("resource-defaults"),
    deleteResource: document.getElementById("delete-resource"),
    infrastructureDialog: document.getElementById("infrastructure-dialog"),
    infrastructureForm: document.getElementById("infrastructure-form"),
    infrastructureName: document.getElementById("infrastructure-name"),
    infrastructureType: document.getElementById("infrastructure-type"),
    infrastructureDetail: document.getElementById("infrastructure-detail"),
    connectionDialog: document.getElementById("connection-dialog"),
    connectionForm: document.getElementById("connection-form"),
    connectionDialogTitle: document.getElementById("connection-dialog-title"),
    connectionId: document.getElementById("connection-id"),
    connectionFrom: document.getElementById("connection-from"),
    connectionKind: document.getElementById("connection-kind"),
    connectionTo: document.getElementById("connection-to"),
    deleteConnection: document.getElementById("delete-connection"),
};

let snapshot;
let firstRender = true;
let proposalRequestPending = false;
let graphResizeFrame;
let graphViewport = { width: 0, height: 0 };

document.addEventListener("DOMContentLoaded", () => {
    elements.scan.addEventListener("click", () => void requestScan());
    elements.rescan.addEventListener("click", () => void requestScan());
    elements.retry.addEventListener("click", () => void loadSnapshot());
    elements.confirm.addEventListener("click", () => void confirmSnapshot());
    elements.apphostStyle.addEventListener("change", () => {
        updateAppHostValue();
        void saveSettings();
    });
    elements.addInfrastructure.addEventListener("click", openInfrastructureDialog);
    elements.addConnection.addEventListener("click", () => openConnectionDialog());
    elements.resourceForm.addEventListener("submit", saveResource);
    elements.deleteResource.addEventListener("click", () => void deleteResource());
    elements.infrastructureForm.addEventListener("submit", addInfrastructure);
    elements.connectionForm.addEventListener("submit", saveConnection);
    elements.connectionFrom.addEventListener("change", () => syncConnectionTargets());
    elements.deleteConnection.addEventListener("click", () => void deleteConnection());
    for (const button of document.querySelectorAll("[data-close-dialog]")) {
        button.addEventListener("click", () => button.closest("dialog")?.close());
    }
    observeGraphSize();

    void loadSnapshot();
    connectEvents();
});

function updateAppHostValue() {
    elements.apphostValue.textContent =
        elements.apphostStyle.selectedOptions[0]?.textContent ?? "";
}

function observeGraphSize() {
    if (typeof ResizeObserver !== "function") {
        return;
    }
    const observer = new ResizeObserver(([entry]) => {
        const width = Math.round(entry.contentRect.width);
        const height = Math.round(entry.contentRect.height);
        if (
            Math.abs(width - graphViewport.width) < 2 &&
            Math.abs(height - graphViewport.height) < 2
        ) {
            return;
        }
        graphViewport = { width, height };
        cancelAnimationFrame(graphResizeFrame);
        graphResizeFrame = requestAnimationFrame(() => {
            if (snapshot?.proposalLoaded && !elements.graphPanel.hidden) {
                renderGraph();
            }
        });
    });
    observer.observe(elements.graphScroll);
}

async function loadSnapshot() {
    showLoading();
    try {
        const response = await fetch("/api/snapshot");
        if (!response.ok) {
            throw new Error(`Snapshot request failed (${response.status}).`);
        }
        render(await response.json());
    } catch (error) {
        showError(error);
    }
}

function connectEvents() {
    const events = new EventSource("/events");
    events.onmessage = (event) => {
        try {
            const message = JSON.parse(event.data);
            if (message.type === "snapshot") {
                proposalRequestPending = false;
                render(message.snapshot);
            }
        } catch {
            showError(new Error("The canvas received an invalid snapshot."));
        }
    };
}

async function post(path, body) {
    const response = await fetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
        throw new Error(payload.error ?? "The canvas action failed.");
    }
    return payload;
}

async function runBusy(control, action) {
    elements.body.classList.add("is-busy");
    if (control) {
        control.disabled = true;
    }
    try {
        await action();
    } catch (error) {
        showInlineError(error);
    } finally {
        elements.body.classList.remove("is-busy");
        if (control) {
            control.disabled = false;
        }
    }
}

async function requestScan() {
    await runBusy(elements.rescan, async () => {
        await post("/api/rescan", {});
    });
}

async function requestProposal() {
    if (proposalRequestPending || !snapshot?.discoveryLoaded) {
        return;
    }
    proposalRequestPending = true;
    try {
        await post("/api/proposal/request", {});
    } catch (error) {
        proposalRequestPending = false;
        showInlineError(error);
    }
}

async function confirmSnapshot() {
    const originalLabel = elements.confirm.textContent;
    await runBusy(elements.confirm, async () => {
        elements.confirm.textContent = "Confirming…";
        try {
            await post("/api/confirm", {});
        } catch (error) {
            elements.confirm.textContent = originalLabel;
            throw error;
        }
    });
}

function render(nextSnapshot) {
    const draw = () => {
        snapshot = nextSnapshot;
        if (snapshot.scanStatus === "idle") {
            showIdle();
            firstRender = false;
            return;
        }
        if (snapshot.scanStatus === "scanning") {
            showScanPending();
            firstRender = false;
            return;
        }

        elements.body.classList.remove("is-loading");
        elements.body.classList.remove("is-scanning");
        elements.idle.hidden = true;
        elements.skeleton.hidden = true;
        elements.error.hidden = true;
        elements.snapshot.hidden = false;
        elements.actionFooter.hidden = false;
        elements.apphostControl.hidden = !snapshot.apphostStyle;
        elements.rescan.hidden = false;
        elements.apphostStyle.value = snapshot.apphostStyle;
        updateAppHostValue();
        elements.rescan.disabled = false;
        elements.scanActionLabel.textContent = "Re-scan";

        const hasPlan = snapshot.proposalLoaded;
        elements.body.classList.toggle("is-loading", !hasPlan || snapshot.proposalStale);
        elements.planPending.hidden = hasPlan;
        elements.planContent.hidden = !hasPlan;
        if (hasPlan) {
            renderGraph();
        }
        renderStatus();
        renderConfirmation();

        if ((!snapshot.proposalLoaded || snapshot.proposalStale) && snapshot.discoveryLoaded) {
            queueMicrotask(() => void requestProposal());
        }
        firstRender = false;
    };

    if (!firstRender && typeof document.startViewTransition === "function") {
        document.startViewTransition(draw);
    } else {
        draw();
    }
}

function renderGraph() {
    const proposal = snapshot.proposal;
    const resources = proposal.resources.filter((resource) => resource.include);
    const names = new Set(resources.map((resource) => resource.name));
    const edges = proposal.edges.filter((edge) => names.has(edge.from) && names.has(edge.to));
    const showGraph = resources.length > 0;
    elements.graphPanel.hidden = false;
    elements.graphScroll.hidden = !showGraph;
    elements.graphPanel.classList.toggle("is-single", resources.length === 1);
    elements.addConnection.disabled = resources.length < 2;
    elements.graph.replaceChildren();
    if (!showGraph) {
        return;
    }

    const layout = graphLayout(resources, edges, {
        width: elements.graphScroll.clientWidth,
        height: elements.graphScroll.clientHeight,
    });
    elements.graph.setAttribute("viewBox", `0 0 ${layout.width} ${layout.height}`);
    elements.graph.setAttribute("width", String(layout.width));
    elements.graph.setAttribute("height", String(layout.height));
    elements.graph.style.width = `${layout.width}px`;
    elements.graph.style.height = `${layout.height}px`;
    elements.graph.append(createSvgElement("title", {}, "AppHost dependency graph"));
    const defs = createSvgElement("defs");
    const marker = createSvgElement("marker", {
        id: "arrow",
        markerWidth: "8",
        markerHeight: "8",
        refX: "7",
        refY: "4",
        orient: "auto",
    });
    marker.append(createSvgElement("path", { d: "M0,0 L8,4 L0,8 Z", class: "graph-arrow" }));
    defs.append(marker);
    elements.graph.append(defs);

    for (const edge of edges) {
        const from = layout.positions.get(edge.from);
        const to = layout.positions.get(edge.to);
        if (!from || !to) {
            continue;
        }
        const vertical = layout.orientation === "vertical";
        const x1 = vertical
            ? from.x + layout.nodeWidth / 2
            : from.x > to.x
              ? from.x
              : from.x + layout.nodeWidth;
        const x2 = vertical
            ? to.x + layout.nodeWidth / 2
            : from.x > to.x
              ? to.x + layout.nodeWidth
              : to.x;
        const fromHeight = from.height ?? layout.nodeHeight;
        const toHeight = to.height ?? layout.nodeHeight;
        const y1 = vertical ? from.y + fromHeight : from.y + fromHeight / 2;
        const y2 = vertical ? to.y : to.y + toHeight / 2;
        const path = vertical
            ? `M${x1},${y1} C${x1},${(y1 + y2) / 2} ${x2},${(y1 + y2) / 2} ${x2},${y2}`
            : `M${x1},${y1} C${(x1 + x2) / 2},${y1} ${(x1 + x2) / 2},${y2} ${x2},${y2}`;
        const group = createSvgElement("g", {
            class: "graph-edge-control",
            role: "button",
            tabindex: "0",
            "aria-label": `Edit connection from ${edge.from} to ${edge.to}`,
        });
        const label = EDGE_LABELS[edge.kind] ?? edge.kind;
        const labelX = (x1 + x2) / 2;
        const labelY = (y1 + y2) / 2;
        const labelWidth = Math.max(48, label.length * 6.2 + 16);
        group.append(
            createSvgElement("title", {}, `${edge.from} ${label} ${edge.to}`),
            createSvgElement("path", {
                d: path,
                class: "graph-edge-hit",
            }),
            createSvgElement("path", {
                d: path,
                class: "graph-edge",
                "marker-end": "url(#arrow)",
            }),
            createSvgElement("rect", {
                x: String(labelX - labelWidth / 2),
                y: String(labelY - 11),
                width: String(labelWidth),
                height: "22",
                rx: "11",
                class: "graph-edge-label-bg",
            }),
            createSvgElement(
                "text",
                {
                    x: String(labelX),
                    y: String(labelY + 4),
                    class: "graph-edge-label",
                    "text-anchor": "middle",
                },
                label,
            ),
        );
        makeGraphControl(group, () => openConnectionDialog(edge.id));
        elements.graph.append(group);
    }

    for (const resource of resources) {
        const position = layout.positions.get(resource.name);
        const service = serviceForResource(resource);
        const status = graphNodeStatus(resource);
        const details = [
            resource.name,
            resource.type,
            resource.detail,
            service?.framework,
            service?.path,
            status,
        ]
            .filter(Boolean)
            .join("\n");
        const group = createSvgElement("g", {
            class: `graph-node resource-${resourceKind(resource)}`,
            transform: `translate(${position.x},${position.y})`,
            role: "button",
            tabindex: "0",
            "aria-label": `Edit resource ${resource.name}`,
        });
        group.append(
            createSvgElement("title", {}, details),
            createSvgElement("rect", {
                width: String(layout.nodeWidth),
                height: String(position.height ?? layout.nodeHeight),
                rx: "7",
            }),
            createSvgElement(
                "text",
                { x: "16", y: "27", class: "graph-node-name" },
                truncate(resource.name, 24),
            ),
            createSvgElement(
                "text",
                { x: "16", y: "51", class: "graph-node-type" },
                truncate(resource.type, 30),
            ),
        );
        if (status) {
            group.append(
                createSvgElement(
                    "text",
                    { x: "16", y: "74", class: "graph-node-meta" },
                    truncate(status, 30),
                ),
            );
        }
        makeGraphControl(group, () => openResourceDialog(resource.id));
        elements.graph.append(group);
    }
}

function makeGraphControl(element, openEditor) {
    const showEditState = () => element.classList.add("is-active");
    const hideEditState = () => element.classList.remove("is-active");
    element.addEventListener("mouseenter", showEditState);
    element.addEventListener("mouseleave", hideEditState);
    element.addEventListener("focus", showEditState);
    element.addEventListener("blur", hideEditState);
    element.addEventListener("click", openEditor);
    element.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") {
            return;
        }
        event.preventDefault();
        openEditor();
    });
}

function graphLayout(resources, edges, viewport) {
    const longestLabel = Math.max(
        ...resources.flatMap((resource) => [
            String(resource.name).length,
            String(resource.type).length,
        ]),
    );
    const desiredNodeWidth = Math.min(260, Math.max(220, longestLabel * 7.2 + 36));
    let nodeWidth = desiredNodeWidth;
    const nodeHeight = 92;
    const itemGap = 18;
    const padding = 16;
    const availableWidth = Math.max(viewport.width || 0, 320);
    const availableHeight = Math.max(viewport.height || 0, 180);
    const levels = new Map(resources.map((resource) => [resource.name, 0]));
    for (let pass = 0; pass < resources.length; pass += 1) {
        let changed = false;
        for (const edge of edges) {
            const nextLevel = Math.min(resources.length - 1, (levels.get(edge.to) ?? 0) + 1);
            if ((levels.get(edge.from) ?? 0) < nextLevel) {
                levels.set(edge.from, nextLevel);
                changed = true;
            }
        }
        if (!changed) {
            break;
        }
    }
    const columns = new Map();
    for (const resource of resources) {
        const level = levels.get(resource.name) ?? 0;
        if (!columns.has(level)) {
            columns.set(level, []);
        }
        columns.get(level).push(resource);
    }
    const orderedLevels = [...columns.keys()].sort((left, right) => right - left);
    const positions = new Map();

    if (edges.length === 0 || orderedLevels.length === 1) {
        const columnCount = Math.max(
            1,
            Math.min(
                resources.length,
                Math.floor(
                    (availableWidth - padding * 2 + itemGap) /
                        (Math.min(nodeWidth, 196) + itemGap),
                ),
            ),
        );
        nodeWidth = Math.min(
            nodeWidth,
            (availableWidth - padding * 2 - (columnCount - 1) * itemGap) / columnCount,
        );
        const rowCount = Math.ceil(resources.length / columnCount);
        const contentWidth = columnCount * nodeWidth + (columnCount - 1) * itemGap;
        const contentHeight = rowCount * nodeHeight + (rowCount - 1) * itemGap;
        const width = availableWidth;
        const height = Math.max(availableHeight, contentHeight + padding * 2);
        const offsetX = (width - contentWidth) / 2;
        const offsetY = (height - contentHeight) / 2;
        resources.forEach((resource, index) => {
            positions.set(resource.name, {
                x: offsetX + (index % columnCount) * (nodeWidth + itemGap),
                y: offsetY + Math.floor(index / columnCount) * (nodeHeight + itemGap),
            });
        });
        return finalizeGraphLayout({
            width,
            height,
            nodeWidth,
            nodeHeight,
            positions,
            orientation: "grid",
        }, resources);
    }

    const maxRows = Math.max(...[...columns.values()].map((column) => column.length));
    const minimumHorizontalGap = 72;
    const minimumHorizontalWidth =
        padding * 2 +
        orderedLevels.length * nodeWidth +
        (orderedLevels.length - 1) * minimumHorizontalGap;
    const minimumHorizontalHeight =
        padding * 2 + maxRows * nodeHeight + (maxRows - 1) * itemGap;
    const orientation =
        availableWidth >= minimumHorizontalWidth &&
        availableHeight >= minimumHorizontalHeight &&
        availableWidth >= availableHeight * 1.05
            ? "horizontal"
            : "vertical";

    if (orientation === "horizontal") {
        const width = availableWidth;
        const horizontalGap =
            orderedLevels.length > 1
                ? Math.min(
                      180,
                      (width - padding * 2 - orderedLevels.length * nodeWidth) /
                          (orderedLevels.length - 1),
                  )
                : 0;
        const contentWidth =
            orderedLevels.length * nodeWidth + (orderedLevels.length - 1) * horizontalGap;
        const contentHeight = maxRows * nodeHeight + (maxRows - 1) * itemGap;
        const height = Math.max(availableHeight, contentHeight + padding * 2);
        const offsetX = (width - contentWidth) / 2;
        orderedLevels.forEach((level, columnIndex) => {
            const column = columns.get(level);
            const columnHeight = column.length * nodeHeight + (column.length - 1) * itemGap;
            const offsetY = (height - columnHeight) / 2;
            column.forEach((resource, rowIndex) => {
                positions.set(resource.name, {
                    x: offsetX + columnIndex * (nodeWidth + horizontalGap),
                    y: offsetY + rowIndex * (nodeHeight + itemGap),
                });
            });
        });
        return finalizeGraphLayout(
            { width, height, nodeWidth, nodeHeight, positions, orientation },
            resources,
        );
    }

    const maxColumns = Math.max(...[...columns.values()].map((row) => row.length));
    const columnsPerRow = Math.max(
        1,
        Math.min(
            maxColumns,
            Math.floor((availableWidth - padding * 2 + itemGap) / (196 + itemGap)),
        ),
    );
    nodeWidth = Math.min(
        nodeWidth,
        (availableWidth - padding * 2 - (columnsPerRow - 1) * itemGap) / columnsPerRow,
    );
    const levelRows = orderedLevels.map((level) => {
        const resourcesAtLevel = columns.get(level);
        const rows = [];
        for (let index = 0; index < resourcesAtLevel.length; index += columnsPerRow) {
            rows.push(resourcesAtLevel.slice(index, index + columnsPerRow));
        }
        return rows;
    });
    const totalNodeRows = levelRows.reduce((total, rows) => total + rows.length, 0);
    const internalRowCount = totalNodeRows - orderedLevels.length;
    const nodeContentHeight =
        totalNodeRows * nodeHeight + internalRowCount * itemGap;
    const height = availableHeight;
    const levelGap =
        orderedLevels.length > 1
            ? Math.max(
                  40,
                  Math.min(
                      110,
                      (height - padding * 2 - nodeContentHeight) /
                          (orderedLevels.length - 1),
                  ),
              )
            : 0;
    const contentHeight =
        nodeContentHeight + (orderedLevels.length - 1) * levelGap;
    const width = availableWidth;
    const offsetY = (height - contentHeight) / 2;
    let y = Math.max(padding, offsetY);
    levelRows.forEach((rows, levelIndex) => {
        rows.forEach((row, rowIndex) => {
            const rowWidth = row.length * nodeWidth + (row.length - 1) * itemGap;
            const offsetX = (width - rowWidth) / 2;
            row.forEach((resource, columnIndex) => {
                positions.set(resource.name, {
                    x: offsetX + columnIndex * (nodeWidth + itemGap),
                    y,
                });
            });
            y += nodeHeight;
            if (rowIndex < rows.length - 1) {
                y += itemGap;
            }
        });
        if (levelIndex < levelRows.length - 1) {
            y += levelGap;
        }
    });
    return finalizeGraphLayout(
        { width, height, nodeWidth, nodeHeight, positions, orientation },
        resources,
    );
}

function finalizeGraphLayout(layout, resources) {
    for (const resource of resources) {
        const position = layout.positions.get(resource.name);
        if (!position) {
            continue;
        }
        const height = graphNodeStatus(resource) ? layout.nodeHeight : 76;
        position.y += (layout.nodeHeight - height) / 2;
        position.height = height;
    }
    return layout;
}

function graphNodeStatus(resource) {
    const service = serviceForResource(resource);
    return [
        service?.exposesHttp ? "HTTP" : "",
        service?.serviceDefaults ? "Service Defaults" : "",
    ]
        .filter(Boolean)
        .join(" · ");
}

function renderStatus() {
    const resources = snapshot.proposal.resources ?? [];
    const includedNames = new Set(
        resources.filter((resource) => resource.include).map((resource) => resource.name),
    );
    const activeEdges = snapshot.proposal.edges.filter(
        (edge) => includedNames.has(edge.from) && includedNames.has(edge.to),
    ).length;
    if (snapshot.scanError) {
        elements.statusLine.textContent = snapshot.scanError;
    } else if (!snapshot.proposalLoaded || snapshot.proposalStale) {
        elements.statusLine.textContent = "Updating the dependency graph…";
    } else if (snapshot.confirmed) {
        elements.statusLine.textContent = "Dependency graph confirmed";
    } else {
        elements.statusLine.textContent = `${includedNames.size} resource${
            includedNames.size === 1 ? "" : "s"
        } · ${activeEdges} connection${activeEdges === 1 ? "" : "s"} · No files changed`;
    }
}

function renderConfirmation() {
    const issues = confirmationIssues();
    elements.confirm.disabled =
        !snapshot.proposalLoaded || snapshot.proposalStale || issues.length > 0 || snapshot.confirmed;
    elements.confirm.textContent = snapshot.confirmed ? "Confirmed" : "Confirm & wire";
    elements.footerNote.hidden = issues.length === 0;
    elements.footerNote.textContent = issues.join(" ");
}

function confirmationIssues() {
    if (!snapshot.proposalLoaded || snapshot.proposalStale) {
        return [];
    }
    const issues = [];
    const included = snapshot.proposal.resources.filter((resource) => resource.include);
    const names = new Set();
    if (included.length === 0) {
        issues.push("Include at least one resource.");
    }
    for (const resource of included) {
        const key = resource.name.toLowerCase();
        if (
            !/^[A-Za-z][A-Za-z0-9-]{0,63}$/.test(resource.name) ||
            resource.name.endsWith("-") ||
            resource.name.includes("--") ||
            !resource.type.trim() ||
            names.has(key)
        ) {
            issues.push("Fix invalid or duplicate resource names and types.");
            break;
        }
        names.add(key);
    }
    for (const edge of snapshot.proposal.edges) {
        if (edge.from === edge.to) {
            issues.push("A resource cannot connect to itself.");
            break;
        }
    }
    return issues;
}

function openResourceDialog(resourceId) {
    const resource = snapshot.proposal.resources.find((candidate) => candidate.id === resourceId);
    if (!resource) {
        return;
    }
    const service = serviceForResource(resource);
    elements.resourceId.value = resource.id;
    elements.resourceName.value = resource.name;
    setSelectValue(elements.resourceType, resource.type);
    elements.resourceDialogDetail.textContent =
        [service?.name, service?.framework, service?.path].filter(Boolean).join(" · ") ||
        resource.detail ||
        "Infrastructure resource";
    elements.defaultsField.hidden = service?.type !== "dotnet";
    elements.resourceDefaults.checked = Boolean(service?.serviceDefaults);
    elements.resourceDialog.showModal();
}

function setSelectValue(select, value) {
    const normalized = String(value ?? "").trim();
    for (const option of [...select.options]) {
        if (option.dataset.detected === "true") {
            option.remove();
        }
    }
    const existing = [...select.options].find((option) => option.value === normalized);
    if (!existing && normalized) {
        const option = new Option(`${normalized} (detected)`, normalized);
        option.dataset.detected = "true";
        select.prepend(option);
    }
    select.value = normalized;
}

async function saveResource(event) {
    event.preventDefault();
    const id = elements.resourceId.value;
    const resource = snapshot.proposal.resources.find((candidate) => candidate.id === id);
    if (!resource) {
        return;
    }
    const service = serviceForResource(resource);
    await runBusy(event.submitter, async () => {
        await post("/api/proposal/resource", {
            id,
            name: elements.resourceName.value,
            type: elements.resourceType.value,
        });
        if (service?.type === "dotnet" && service.serviceDefaults !== elements.resourceDefaults.checked) {
            await post("/api/service/defaults", {
                id: service.id,
                value: elements.resourceDefaults.checked,
            });
        }
        elements.resourceDialog.close();
    });
}

async function deleteResource() {
    const id = elements.resourceId.value;
    await runBusy(elements.deleteResource, async () => {
        await post("/api/proposal/resource/delete", { id });
        elements.resourceDialog.close();
    });
}

function openInfrastructureDialog() {
    elements.infrastructureForm.reset();
    elements.infrastructureDialog.showModal();
    elements.infrastructureName.focus();
}

async function addInfrastructure(event) {
    event.preventDefault();
    await runBusy(event.submitter, async () => {
        await post("/api/proposal/resource/add", {
            name: elements.infrastructureName.value,
            type: elements.infrastructureType.value,
            detail: elements.infrastructureDetail.value,
        });
        elements.infrastructureDialog.close();
    });
}

function openConnectionDialog(edgeId = "") {
    const edge = snapshot.proposal.edges.find((candidate) => candidate.id === edgeId);
    const resources = edge
        ? snapshot.proposal.resources
        : snapshot.proposal.resources.filter((resource) => resource.include);
    if (resources.length < 2) {
        showInlineError(new Error("Include at least two resources before adding a connection."));
        return;
    }
    fillResourceSelect(elements.connectionFrom, resources);
    elements.connectionId.value = edge?.id ?? "";
    elements.connectionDialogTitle.textContent = edge ? "Edit connection" : "Add connection";
    elements.connectionFrom.value = edge?.from ?? resources[0].name;
    syncConnectionTargets(edge?.to ?? resources[1].name);
    elements.connectionKind.value = edge?.kind ?? "reference";
    elements.deleteConnection.hidden = !edge;
    elements.connectionDialog.showModal();
}

async function saveConnection(event) {
    event.preventDefault();
    if (elements.connectionFrom.value === elements.connectionTo.value) {
        elements.connectionTo.setCustomValidity("Choose a different target resource.");
        elements.connectionTo.reportValidity();
        return;
    }
    elements.connectionTo.setCustomValidity("");
    const id = elements.connectionId.value;
    const path = id ? "/api/proposal/edge" : "/api/proposal/edge/add";
    await runBusy(event.submitter, async () => {
        await post(path, {
            id,
            from: elements.connectionFrom.value,
            kind: elements.connectionKind.value,
            to: elements.connectionTo.value,
        });
        elements.connectionDialog.close();
    });
}

function syncConnectionTargets(preferredTarget = elements.connectionTo.value) {
    const targets = snapshot.proposal.resources.filter(
        (resource) =>
            (elements.connectionId.value || resource.include) &&
            resource.name !== elements.connectionFrom.value,
    );
    fillResourceSelect(elements.connectionTo, targets);
    elements.connectionTo.value = targets.some((resource) => resource.name === preferredTarget)
        ? preferredTarget
        : (targets[0]?.name ?? "");
    elements.connectionTo.setCustomValidity("");
}

async function deleteConnection() {
    await runBusy(elements.deleteConnection, async () => {
        await post("/api/proposal/edge/delete", { id: elements.connectionId.value });
        elements.connectionDialog.close();
    });
}

async function saveSettings() {
    if (elements.apphostStyle.value === snapshot.apphostStyle) {
        return;
    }
    const previousStyle = snapshot.apphostStyle;
    await runBusy(elements.apphostStyle, async () => {
        try {
            await post("/api/style", { value: elements.apphostStyle.value });
        } catch (error) {
            elements.apphostStyle.value = previousStyle;
            updateAppHostValue();
            throw error;
        }
    });
}

function fillResourceSelect(select, resources) {
    select.replaceChildren();
    for (const resource of resources) {
        select.append(
            createElement("option", { text: resource.name, attrs: { value: resource.name } }),
        );
    }
}

function serviceForResource(resource) {
    return snapshot.services.find((service) => service.id === resource.serviceId);
}

function resourceKind(resource) {
    const type = String(resource.type ?? "").toLowerCase();
    if (/next|vite|frontend|web/.test(type)) return "frontend";
    if (/postgres|sql|database|mongo|cosmos/.test(type)) return "database";
    if (/redis|cache/.test(type)) return "cache";
    if (/rabbit|broker|service bus|messag/.test(type)) return "broker";
    if (/container|docker/.test(type)) return "container";
    return resource.serviceId ? "project" : "external";
}

function showLoading() {
    elements.body.classList.add("is-loading");
    elements.body.classList.remove("is-scanning");
    elements.idle.hidden = true;
    elements.skeleton.hidden = false;
    elements.snapshot.hidden = true;
    elements.actionFooter.hidden = true;
    elements.error.hidden = true;
    elements.apphostControl.hidden = true;
    elements.rescan.hidden = true;
    elements.statusLine.textContent = "Loading plan…";
}

function showIdle() {
    elements.body.classList.remove("is-loading", "is-busy", "is-scanning");
    elements.idle.hidden = false;
    elements.skeleton.hidden = true;
    elements.snapshot.hidden = true;
    elements.actionFooter.hidden = true;
    elements.error.hidden = true;
    elements.apphostControl.hidden = true;
    elements.rescan.hidden = true;
    elements.statusLine.textContent = snapshot.scanError || "No scan has run";
    elements.idleTitle.textContent = snapshot.scanError ? "Scan didn’t finish" : "Ready to scan";
    elements.idleDetail.textContent =
        snapshot.scanError ||
        "Find runnable services, infrastructure, configuration, and dependencies, then prepare a dependency graph for review.";
}

function showScanPending() {
    elements.body.classList.add("is-loading", "is-scanning");
    elements.idle.hidden = true;
    elements.skeleton.hidden = false;
    elements.snapshot.hidden = true;
    elements.actionFooter.hidden = true;
    elements.error.hidden = true;
    elements.apphostControl.hidden = true;
    elements.rescan.hidden = false;
    elements.rescan.disabled = true;
    elements.scanActionLabel.textContent = "Scanning…";
    elements.statusLine.textContent = "Scanning repository…";
}

function showError(error) {
    elements.body.classList.remove("is-loading", "is-busy", "is-scanning");
    elements.idle.hidden = true;
    elements.skeleton.hidden = true;
    elements.snapshot.hidden = true;
    elements.actionFooter.hidden = true;
    elements.error.hidden = false;
    elements.apphostControl.hidden = true;
    elements.rescan.hidden = true;
    elements.statusLine.textContent = "Plan unavailable";
    elements.errorMessage.textContent = error?.message ?? String(error);
}

function showInlineError(error) {
    elements.footerNote.hidden = false;
    elements.footerNote.textContent = error?.message ?? String(error);
}

function createElement(tag, options = {}) {
    const element = document.createElement(tag);
    if (options.className) element.className = options.className;
    if (typeof options.text !== "undefined") element.textContent = options.text;
    if (options.title) element.title = options.title;
    for (const [name, value] of Object.entries(options.attrs ?? {})) {
        element.setAttribute(name, value);
    }
    return element;
}

function createSvgElement(tag, attributes = {}, text = "") {
    const element = document.createElementNS(SVG_NS, tag);
    for (const [name, value] of Object.entries(attributes)) {
        element.setAttribute(name, value);
    }
    if (text) {
        element.textContent = text;
    }
    return element;
}

function truncate(value, length) {
    const text = String(value ?? "");
    return text.length > length ? `${text.slice(0, length - 1)}…` : text;
}
