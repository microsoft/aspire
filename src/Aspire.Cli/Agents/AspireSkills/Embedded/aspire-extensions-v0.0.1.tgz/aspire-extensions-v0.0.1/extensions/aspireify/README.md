# Aspireify canvas

This canvas is Aspireify's confirmation boundary: a single editable dependency
graph shown after scanning and before any files change.

The skill owns repository discovery, proposal logic, AppHost edits, and
validation. The canvas only:

1. receives the detected AppHost style and discovered runnable services through
   `load_discovery`;
2. receives resources and connections through `set_proposal`;
3. presents those findings as one editable dependency graph;
4. lets the user add or remove graph resources, rename or retype resources,
   enable Service Defaults, add infrastructure, and edit connections directly
   on the graph using a constrained Aspire-aware resource-type selector;
5. requests a regenerated proposal when a service-level choice changes while
   preserving user-added resources and connections; and
6. returns the confirmed service choices and edited plan through
   `get_confirmation`.

Connections are directed: `from` references, waits for, or is a child of `to`.
The graph arrowhead always points at `to`.

It intentionally has no scanner, proposal generator, AppHost editor, deployment
controls, or validation workflow.

The extension's `onPostToolUse` hook opens or focuses the canvas after a
successful `aspireify` skill invocation. This behavior belongs to the canvas
extension; the skill does not need to open the panel itself.
