// Aspireify plan canvas: present discovery, show the proposed AppHost, and
// return the user's confirmation. Scanning, plan logic, and wiring remain in the skill.

import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { createCanvas, joinSession } from "@github/copilot-sdk/extension";

const CANVAS_ID = "aspireify-graph";
const DEFAULT_INSTANCE_ID = "aspireify-main";
const UI_DIRECTORY_URL = new URL("./ui/", import.meta.url);
const UI_DIRECTORY = resolve(fileURLToPath(UI_DIRECTORY_URL));
const BODY_LIMIT = 256 * 1024;
const SCAN_TIMEOUT_MS = 120_000;

const CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
};

const APPHOST_STYLES = new Set(["csharp-sdk", "csharp-file", "typescript"]);
const SERVICE_TYPES = new Set(["dotnet", "node", "python", "dockerfile", "container", "executable"]);
const TYPE_ALIASES = new Map([
    ["c#", "dotnet"],
    ["csharp", "dotnet"],
    ["csproj", "dotnet"],
    ["dotnet", "dotnet"],
    ["project", "dotnet"],
    ["javascript", "node"],
    ["nextjs", "node"],
    ["node", "node"],
    ["nodejs", "node"],
    ["npm", "node"],
    ["typescript", "node"],
    ["vite", "node"],
    ["fastapi", "python"],
    ["flask", "python"],
    ["py", "python"],
    ["python", "python"],
    ["docker", "dockerfile"],
    ["dockerfile", "dockerfile"],
    ["container", "container"],
    ["image", "container"],
    ["exe", "executable"],
    ["executable", "executable"],
    ["process", "executable"],
]);

const instances = new Map();
const snapshots = new Map();
const scanTimers = new Map();
let sessionRef;

function emptySnapshot(appHostPath = "") {
    return {
        appHostPath,
        repoName: "",
        scanStatus: "idle",
        scanError: "",
        discoveryLoaded: false,
        proposalLoaded: false,
        apphostStyle: null,
        services: [],
        proposal: {
            resources: [],
            edges: [],
        },
        proposalEdited: false,
        proposalStale: false,
        confirmed: false,
        updatedAt: Date.now(),
    };
}

function domainIdFrom(input) {
    return String(input?.appHostPath ?? "").trim() || "default";
}

function domainIdForContext(context) {
    return instances.get(context.instanceId)?.domainId ?? domainIdFrom(context.input);
}

function getSnapshot(domainId) {
    if (!snapshots.has(domainId)) {
        snapshots.set(domainId, emptySnapshot(domainId === "default" ? "" : domainId));
    }
    return snapshots.get(domainId);
}

function normalizeType(value) {
    const key = String(value ?? "")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, "");
    return TYPE_ALIASES.get(key) ?? (SERVICE_TYPES.has(key) ? key : "executable");
}

function resourceNameFrom(value, index) {
    const normalized = String(value ?? "")
        .trim()
        .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
        .replace(/[^A-Za-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .toLowerCase();
    const prefixed = /^[a-z]/.test(normalized) ? normalized : `service-${normalized}`;
    return (prefixed || `service-${index + 1}`).slice(0, 64).replace(/-+$/g, "");
}

function normalizeService(service, index) {
    const type = normalizeType(service?.type);
    const name = String(service?.name ?? `Service ${index + 1}`).trim() || `Service ${index + 1}`;
    const include = typeof service?.include === "boolean" ? service.include : true;
    return {
        id: String(service?.id ?? resourceNameFrom(name, index)),
        name,
        type,
        framework: String(service?.framework ?? "").trim(),
        exposesHttp: Boolean(service?.exposesHttp),
        path: String(service?.path ?? "").trim(),
        include,
        resourceName: String(service?.resourceName ?? resourceNameFrom(name, index)).trim(),
        serviceDefaults:
            include &&
            type === "dotnet" &&
            (typeof service?.serviceDefaults === "boolean" ? service.serviceDefaults : true),
    };
}

function normalizeResourceType(value) {
    const text = String(value ?? "").trim();
    const normalized = text.toLowerCase();
    const aliases = [
        [/next(?:\.js|js)?/, "Next.js"],
        [/\bvite\b/, "Vite"],
        [/asp\.net|\.net|dotnet|csharp|csproj/, ".NET project"],
        [/\bnode(?:\.js|js)?\b/, "Node.js"],
        [/\bpython\b|fastapi|flask/, "Python"],
        [/\bpostgres(?:ql)?\b/, "Postgres"],
        [/\bredis\b/, "Redis"],
        [/\brabbitmq\b/, "RabbitMQ"],
        [/\bmongo(?:db)?\b/, "MongoDB"],
        [/\bsql server\b/, "SQL Server"],
        [/\bmysql\b/, "MySQL"],
        [/\bcosmos\b/, "Azure Cosmos DB"],
        [/\bservice bus\b/, "Azure Service Bus"],
        [/\bcontainer\b|docker/, "Container"],
        [/\bexecutable\b|\bprocess\b/, "Executable"],
    ];
    return aliases.find(([pattern]) => pattern.test(normalized))?.[1] ?? (text || "Executable");
}

function normalizeProposalResource(resource, index, userAdded = false) {
    return {
        id: String(resource?.id ?? `resource-${index + 1}`),
        name: String(resource?.name ?? `resource-${index + 1}`).trim(),
        type: normalizeResourceType(resource?.type),
        serviceId: String(resource?.serviceId ?? "").trim(),
        detail: String(resource?.detail ?? "").trim(),
        include: typeof resource?.include === "boolean" ? resource.include : true,
        userAdded: Boolean(resource?.userAdded ?? userAdded),
        userEdited: Boolean(resource?.userEdited),
    };
}

function normalizeProposalEdge(edge, index, userAdded = false) {
    return {
        id: String(edge?.id ?? `edge-${index + 1}`),
        from: String(edge?.from ?? "").trim(),
        to: String(edge?.to ?? "").trim(),
        kind: ["reference", "waitFor", "parent"].includes(edge?.kind) ? edge.kind : "reference",
        userAdded: Boolean(edge?.userAdded ?? userAdded),
        userEdited: Boolean(edge?.userEdited),
    };
}

function serviceResourceType(type) {
    return {
        dotnet: ".NET project",
        node: "Node.js",
        python: "Python",
        dockerfile: "Container",
        container: "Container",
        executable: "Executable",
    }[type] ?? "Executable";
}

function replaceResourceName(proposal, previousName, nextName) {
    if (!previousName || previousName === nextName) {
        return;
    }
    for (const edge of proposal.edges) {
        if (edge.from === previousName) {
            edge.from = nextName;
        }
        if (edge.to === previousName) {
            edge.to = nextName;
        }
    }
}

function syncServiceResource(state, service, { rename = false, updateType = false } = {}) {
    const resource = state.proposal.resources.find((candidate) => candidate.serviceId === service.id);
    if (!resource) {
        state.proposalStale = state.proposalLoaded;
        return false;
    }

    if (rename) {
        replaceResourceName(state.proposal, resource.name, service.resourceName);
        resource.name = service.resourceName;
    }
    if (updateType) {
        resource.type = serviceResourceType(service.type);
    }
    resource.include = service.include;
    state.proposalEdited = true;
    state.proposalStale = false;
    return true;
}

function isValidResourceName(name) {
    return /^[A-Za-z][A-Za-z0-9-]{0,63}$/.test(name) && !name.endsWith("-") && !name.includes("--");
}

function validateResourceNames(services) {
    const issues = {};
    const names = new Map();
    for (const service of services.filter((candidate) => candidate.include)) {
        const name = service.resourceName.trim();
        const messages = [];
        if (!isValidResourceName(name)) {
            messages.push("Use 1-64 letters, digits, or hyphens; start with a letter.");
        }
        const duplicate = names.get(name.toLowerCase());
        if (duplicate) {
            messages.push(`Duplicates ${duplicate}.`);
        } else if (name) {
            names.set(name.toLowerCase(), service.name);
        }
        if (messages.length) {
            issues[service.id] = messages;
        }
    }
    return issues;
}

function validateProposal(proposal) {
    const issues = [];
    const included = proposal.resources.filter((resource) => resource.include);
    const names = new Set();
    const allNames = new Set(proposal.resources.map((resource) => resource.name.toLowerCase()));
    for (const resource of included) {
        const key = resource.name.toLowerCase();
        if (!isValidResourceName(resource.name)) {
            issues.push(`Resource "${resource.name || "(empty)"}" has an invalid name.`);
        } else if (names.has(key)) {
            issues.push(`Resource name "${resource.name}" is duplicated.`);
        }
        names.add(key);
        if (!resource.type) {
            issues.push(`Resource "${resource.name || resource.id}" needs a type.`);
        }
    }
    if (included.length === 0) {
        issues.push("Include at least one proposed resource.");
    }

    for (const edge of proposal.edges) {
        if (!allNames.has(edge.from.toLowerCase()) || !allNames.has(edge.to.toLowerCase())) {
            issues.push(`Connection "${edge.from}" to "${edge.to}" references a missing resource.`);
        } else if (
            names.has(edge.from.toLowerCase()) &&
            names.has(edge.to.toLowerCase()) &&
            edge.from.toLowerCase() === edge.to.toLowerCase()
        ) {
            issues.push(`Connection "${edge.from}" cannot target itself.`);
        }
    }
    return issues;
}

function confirmedProposal(proposal) {
    const resources = proposal.resources.filter((resource) => resource.include);
    const names = new Set(resources.map((resource) => resource.name));
    return {
        resources: resources.map(({ userAdded, userEdited, ...resource }) => resource),
        edges: proposal.edges
            .filter((edge) => names.has(edge.from) && names.has(edge.to))
            .map(({ userAdded, userEdited, ...edge }) => edge),
    };
}

function broadcast(domainId) {
    const frame = `data: ${JSON.stringify({ type: "snapshot", snapshot: getSnapshot(domainId) })}\n\n`;
    for (const entry of instances.values()) {
        if (entry.domainId !== domainId) {
            continue;
        }
        for (const client of entry.clients) {
            try {
                client.write(frame);
            } catch {
                entry.clients.delete(client);
            }
        }
    }
}

function updateSnapshot(domainId, update) {
    const snapshot = getSnapshot(domainId);
    update(snapshot);
    snapshot.updatedAt = Date.now();
    broadcast(domainId);
    return snapshot;
}

function clearScanTimer(domainId) {
    const timer = scanTimers.get(domainId);
    if (timer) {
        clearTimeout(timer);
        scanTimers.delete(domainId);
    }
}

function scheduleScanTimeout(domainId, isRescan) {
    clearScanTimer(domainId);
    const timer = setTimeout(() => {
        scanTimers.delete(domainId);
        if (getSnapshot(domainId).scanStatus !== "scanning") {
            return;
        }
        updateSnapshot(domainId, (state) => {
            state.scanStatus = isRescan ? "complete" : "idle";
            state.discoveryLoaded = isRescan;
            state.scanError = "The scan did not report results within two minutes. Try again.";
        });
    }, SCAN_TIMEOUT_MS);
    timer.unref();
    scanTimers.set(domainId, timer);
}

function log(message, level = "info") {
    void sessionRef?.log?.(message, { level, ephemeral: true }).catch(() => {});
}

async function sendCanvasMessage(prompt) {
    if (typeof sessionRef?.send !== "function") {
        throw new Error("The active Copilot session is unavailable.");
    }
    await sessionRef.send({ prompt });
}

function confirmationMessage(snapshot) {
    const included = snapshot.services.filter((service) => service.include);
    const excluded = snapshot.services.filter((service) => !service.include);
    const proposal = confirmedProposal(snapshot.proposal);
    return [
        "[aspireify canvas: findings confirmed]",
        "The user confirmed the Aspireify AppHost plan.",
        `AppHost style: ${snapshot.apphostStyle}.`,
        `Included resources: ${
            included.map((service) => `${service.name} -> ${service.resourceName}`).join(", ") || "(none)"
        }.`,
        excluded.length ? `Excluded services: ${excluded.map((service) => service.name).join(", ")}.` : "",
        `Confirmed AppHost resources: ${proposal.resources.map((resource) => `${resource.name} (${resource.type})`).join(", ")}.`,
        `Confirmed connections: ${
            proposal.edges.map((edge) => `${edge.from} -> ${edge.to} (${edge.kind})`).join(", ") || "(none)"
        }.`,
        "Call get_confirmation on the Aspireify canvas and use that result as the source of truth before editing the AppHost.",
    ]
        .filter(Boolean)
        .join("\n");
}

function proposalRequestMessage(snapshot) {
    const included = snapshot.services.filter((service) => service.include);
    const excluded = snapshot.services.filter((service) => !service.include);
    return [
        "[aspireify canvas: review proposal]",
        "The user changed inputs that require the AppHost plan to be regenerated.",
        `AppHost style: ${snapshot.apphostStyle}.`,
        "Included services:",
        ...included.map(
            (service) =>
                `- ${service.name}: resource=${service.resourceName}, type=${service.type}, framework=${service.framework || "(unknown)"}, HTTP=${service.exposesHttp}, ServiceDefaults=${service.serviceDefaults}, path=${service.path}`,
        ),
        excluded.length ? `Excluded services: ${excluded.map((service) => service.name).join(", ")}.` : "",
        "Regenerate the resource graph from these selections, then call set_proposal. Preserve user-added resources and connections. Do not edit any files yet.",
    ]
        .filter(Boolean)
        .join("\n");
}

async function readJsonBody(request) {
    return await new Promise((resolveBody, rejectBody) => {
        let size = 0;
        const chunks = [];
        request.on("data", (chunk) => {
            size += chunk.length;
            if (size > BODY_LIMIT) {
                rejectBody(new Error("Request body is too large."));
                request.destroy();
                return;
            }
            chunks.push(chunk);
        });
        request.on("end", () => {
            try {
                resolveBody(chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {});
            } catch {
                rejectBody(new Error("Request body must be valid JSON."));
            }
        });
        request.on("error", rejectBody);
    });
}

function sendJson(response, status, payload) {
    response.writeHead(status, {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store",
    });
    response.end(JSON.stringify(payload));
}

async function serveAsset(response, assetName) {
    const assetPath = resolve(UI_DIRECTORY, assetName);
    if (!assetPath.startsWith(`${UI_DIRECTORY}${sep}`) && assetPath !== UI_DIRECTORY) {
        response.writeHead(403);
        response.end("Forbidden");
        return;
    }
    try {
        const body = await readFile(assetPath);
        response.writeHead(200, {
            "Content-Type": CONTENT_TYPES[extname(assetName)] ?? "application/octet-stream",
            "Cache-Control": "no-store",
        });
        response.end(body);
    } catch {
        response.writeHead(404);
        response.end("Not found");
    }
}

async function handlePost(entry, path, body, response) {
    const domainId = entry.domainId;
    const snapshot = getSnapshot(domainId);
    const service = snapshot.services.find((candidate) => candidate.id === body.id);
    const proposalResource = snapshot.proposal.resources.find((candidate) => candidate.id === body.id);
    const proposalEdge = snapshot.proposal.edges.find((candidate) => candidate.id === body.id);

    if (path === "/api/service/include" && service) {
        updateSnapshot(domainId, (state) => {
            service.include = Boolean(body.value);
            if (!service.include) {
                service.serviceDefaults = false;
            }
            state.confirmed = false;
            syncServiceResource(state, service);
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/service/name" && service) {
        updateSnapshot(domainId, (state) => {
            service.resourceName = String(body.value ?? "").trim();
            state.confirmed = false;
            syncServiceResource(state, service, { rename: true });
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/service/type" && service) {
        updateSnapshot(domainId, (state) => {
            service.type = normalizeType(body.value);
            service.serviceDefaults = service.include && service.type === "dotnet";
            state.confirmed = false;
            syncServiceResource(state, service, { updateType: true });
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/service/defaults" && service && service.include && service.type === "dotnet") {
        updateSnapshot(domainId, (state) => {
            service.serviceDefaults = Boolean(body.value);
            state.confirmed = false;
            state.proposalStale = true;
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/style" && snapshot.discoveryLoaded && APPHOST_STYLES.has(body.value)) {
        updateSnapshot(domainId, (state) => {
            state.apphostStyle = body.value;
            for (const candidate of state.services) {
                candidate.serviceDefaults = candidate.include && candidate.type === "dotnet";
            }
            state.confirmed = false;
            state.proposalStale = true;
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/proposal/request") {
        if (!snapshot.discoveryLoaded) {
            return sendJson(response, 409, {
                ok: false,
                error: "Discovery must finish before building the proposal.",
            });
        }
        const issues = validateResourceNames(snapshot.services);
        if (Object.keys(issues).length) {
            return sendJson(response, 400, {
                ok: false,
                error: "Fix duplicate or invalid resource names before continuing.",
            });
        }
        if (!snapshot.services.some((candidate) => candidate.include)) {
            return sendJson(response, 400, {
                ok: false,
                error: "Include at least one service before building the proposal.",
            });
        }

        const wasLoaded = snapshot.proposalLoaded;
        updateSnapshot(domainId, (state) => {
            state.proposalLoaded = false;
            state.proposalStale = true;
            state.confirmed = false;
        });
        try {
            await sendCanvasMessage(proposalRequestMessage(snapshot));
        } catch (error) {
            updateSnapshot(domainId, (state) => {
                state.proposalLoaded = wasLoaded;
            });
            throw error;
        }
        return sendJson(response, 202, { ok: true });
    }

    if (path === "/api/proposal/resource" && proposalResource) {
        updateSnapshot(domainId, (state) => {
            const previousName = proposalResource.name;
            if (typeof body.name === "string") {
                proposalResource.name = body.name.trim();
                replaceResourceName(state.proposal, previousName, proposalResource.name);
            }
            if (typeof body.type === "string") {
                proposalResource.type = normalizeResourceType(body.type);
            }
            if (typeof body.include === "boolean") {
                proposalResource.include = body.include;
            }
            proposalResource.userEdited = true;
            const linkedService = state.services.find(
                (candidate) => candidate.id === proposalResource.serviceId,
            );
            if (linkedService) {
                linkedService.resourceName = proposalResource.name;
                linkedService.include = proposalResource.include;
                if (!linkedService.include) {
                    linkedService.serviceDefaults = false;
                }
            }
            state.confirmed = false;
            state.proposalEdited = true;
            state.proposalStale = false;
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/proposal/resource/add") {
        const name = String(body.name ?? "").trim();
        const type = normalizeResourceType(body.type);
        if (!isValidResourceName(name) || !type) {
            return sendJson(response, 400, {
                ok: false,
                error: "Infrastructure needs a valid resource name and type.",
            });
        }
        if (
            snapshot.proposal.resources.some(
                (candidate) => candidate.name.toLowerCase() === name.toLowerCase(),
            )
        ) {
            return sendJson(response, 409, {
                ok: false,
                error: `A resource named "${name}" already exists.`,
            });
        }
        updateSnapshot(domainId, (state) => {
            state.proposal.resources.push(
                normalizeProposalResource(
                    {
                        id: `resource-${Date.now().toString(36)}-${state.proposal.resources.length + 1}`,
                        name,
                        type,
                        detail: String(body.detail ?? "").trim(),
                        include: true,
                    },
                    state.proposal.resources.length,
                    true,
                ),
            );
            state.confirmed = false;
            state.proposalEdited = true;
            state.proposalStale = false;
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/proposal/resource/delete" && proposalResource) {
        updateSnapshot(domainId, (state) => {
            const linkedService = state.services.find(
                (candidate) => candidate.id === proposalResource.serviceId,
            );
            if (linkedService) {
                linkedService.include = false;
                linkedService.serviceDefaults = false;
            }
            state.proposal.resources = state.proposal.resources.filter(
                (candidate) => candidate.id !== proposalResource.id,
            );
            state.proposal.edges = state.proposal.edges.filter(
                (edge) => edge.from !== proposalResource.name && edge.to !== proposalResource.name,
            );
            state.confirmed = false;
            state.proposalEdited = true;
            state.proposalStale = false;
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/proposal/edge" && proposalEdge) {
        const resourceNames = new Set(snapshot.proposal.resources.map((resource) => resource.name));
        const nextFrom = typeof body.from === "string" ? body.from : proposalEdge.from;
        const nextTo = typeof body.to === "string" ? body.to : proposalEdge.to;
        if (
            (typeof body.from === "string" && !resourceNames.has(body.from)) ||
            (typeof body.to === "string" && !resourceNames.has(body.to)) ||
            (typeof body.kind === "string" && !["reference", "waitFor", "parent"].includes(body.kind)) ||
            nextFrom === nextTo
        ) {
            return sendJson(response, 400, { ok: false, error: "Invalid connection update." });
        }
        updateSnapshot(domainId, (state) => {
            if (typeof body.from === "string") {
                proposalEdge.from = body.from;
            }
            if (typeof body.to === "string") {
                proposalEdge.to = body.to;
            }
            if (typeof body.kind === "string") {
                proposalEdge.kind = body.kind;
            }
            proposalEdge.userEdited = true;
            state.confirmed = false;
            state.proposalEdited = true;
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/proposal/edge/delete" && proposalEdge) {
        updateSnapshot(domainId, (state) => {
            state.proposal.edges = state.proposal.edges.filter((candidate) => candidate.id !== proposalEdge.id);
            state.confirmed = false;
            state.proposalEdited = true;
            state.proposalStale = false;
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/proposal/edge/add") {
        const resources = snapshot.proposal.resources.filter((resource) => resource.include);
        if (resources.length < 2) {
            return sendJson(response, 400, {
                ok: false,
                error: "Include at least two resources before adding a connection.",
            });
        }
        const resourceNames = new Set(resources.map((resource) => resource.name));
        const from = String(body.from ?? resources[0].name);
        const to = String(body.to ?? resources[1].name);
        const kind = ["reference", "waitFor", "parent"].includes(body.kind)
            ? body.kind
            : "reference";
        if (!resourceNames.has(from) || !resourceNames.has(to) || from === to) {
            return sendJson(response, 400, { ok: false, error: "Invalid connection." });
        }
        updateSnapshot(domainId, (state) => {
            state.proposal.edges.push(
                normalizeProposalEdge(
                    {
                        id: `edge-${Date.now().toString(36)}-${state.proposal.edges.length + 1}`,
                        from,
                        to,
                        kind,
                    },
                    state.proposal.edges.length,
                    true,
                ),
            );
            state.confirmed = false;
            state.proposalEdited = true;
            state.proposalStale = false;
        });
        return sendJson(response, 200, { ok: true });
    }

    if (path === "/api/rescan") {
        if (snapshot.scanStatus === "scanning") {
            return sendJson(response, 409, { ok: false, error: "A scan is already in progress." });
        }
        const isRescan = snapshot.discoveryLoaded;
        updateSnapshot(domainId, (state) => {
            state.scanStatus = "scanning";
            state.scanError = "";
            state.discoveryLoaded = false;
            state.proposalLoaded = false;
            state.confirmed = false;
        });
        scheduleScanTimeout(domainId, isRescan);
        try {
            await sendCanvasMessage(
                isRescan
                    ? "[aspireify canvas: re-scan]\nRe-run the aspireify scan, then refresh the AppHost plan with load_discovery and set_proposal. Do not edit any files."
                    : "[aspireify canvas: scan]\nRun the aspireify scan, then populate the AppHost plan with load_discovery and set_proposal. Do not edit any files.",
            );
        } catch (error) {
            clearScanTimer(domainId);
            updateSnapshot(domainId, (state) => {
                state.scanStatus = isRescan ? "complete" : "idle";
                state.discoveryLoaded = isRescan;
            });
            throw error;
        }
        return sendJson(response, 202, { ok: true });
    }

    if (path === "/api/confirm") {
        if (!snapshot.discoveryLoaded || !snapshot.proposalLoaded || snapshot.proposalStale) {
            return sendJson(response, 409, {
                ok: false,
                error: "Discovery and proposal must finish before confirmation.",
            });
        }
        const issues = validateResourceNames(snapshot.services);
        if (Object.keys(issues).length) {
            return sendJson(response, 400, { ok: false, issues });
        }
        const proposalIssues = validateProposal(snapshot.proposal);
        if (proposalIssues.length) {
            return sendJson(response, 400, { ok: false, error: proposalIssues.join(" ") });
        }
        updateSnapshot(domainId, (state) => {
            state.confirmed = true;
        });
        await sendCanvasMessage(confirmationMessage(snapshot));
        return sendJson(response, 200, { ok: true });
    }

    return sendJson(response, 404, { ok: false, error: "Unknown action." });
}

async function handleRequest(entry, request, response) {
    const url = new URL(request.url, "http://127.0.0.1");
    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
        return serveAsset(response, "index.html");
    }
    if (request.method === "GET" && ["/app.js", "/styles.css"].includes(url.pathname)) {
        return serveAsset(response, url.pathname.slice(1));
    }
    if (request.method === "GET" && url.pathname === "/api/snapshot") {
        return sendJson(response, 200, getSnapshot(entry.domainId));
    }
    if (request.method === "GET" && url.pathname === "/events") {
        response.writeHead(200, {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive",
        });
        entry.clients.add(response);
        response.write(`data: ${JSON.stringify({ type: "snapshot", snapshot: getSnapshot(entry.domainId) })}\n\n`);
        request.on("close", () => entry.clients.delete(response));
        return;
    }
    if (request.method === "POST") {
        try {
            return await handlePost(entry, url.pathname, await readJsonBody(request), response);
        } catch (error) {
            log(`Aspireify canvas request failed: ${error?.message ?? error}`, "error");
            return sendJson(response, 500, { ok: false, error: error?.message ?? String(error) });
        }
    }
    response.writeHead(404);
    response.end("Not found");
}

async function startServer(instanceId, domainId) {
    const entry = { instanceId, domainId, clients: new Set(), server: undefined, url: "" };
    const server = createServer((request, response) => {
        void handleRequest(entry, request, response).catch((error) => {
            log(`Aspireify canvas server failed: ${error?.message ?? error}`, "error");
            if (!response.headersSent) {
                response.writeHead(500);
            }
            response.end("Internal error");
        });
    });
    await new Promise((resolveListen) => server.listen(0, "127.0.0.1", resolveListen));
    const address = server.address();
    entry.server = server;
    entry.url = `http://127.0.0.1:${typeof address === "object" && address ? address.port : 0}/`;
    instances.set(instanceId, entry);
    return entry;
}

const APPHOST_PATH_SCHEMA = {
    appHostPath: {
        type: "string",
        description: "Path identifying the AppHost whose proposal is being reviewed.",
    },
};

const SERVICE_SCHEMA = {
    type: "object",
    additionalProperties: false,
    properties: {
        id: { type: "string" },
        name: { type: "string" },
        type: {
            type: "string",
            description: "Runnable service type: dotnet, node, python, dockerfile, container, or executable.",
        },
        framework: { type: "string" },
        exposesHttp: { type: "boolean" },
        path: { type: "string" },
        resourceName: { type: "string" },
        include: { type: "boolean" },
        serviceDefaults: { type: "boolean" },
    },
    required: ["name", "type", "framework", "exposesHttp", "path"],
};

const aspireifyCanvas = createCanvas({
    id: CANVAS_ID,
    displayName: "Aspireify",
    description:
        "Edit an Aspireify dependency graph, then confirm what the skill should wire.",
    inputSchema: {
        type: "object",
        additionalProperties: false,
        properties: APPHOST_PATH_SCHEMA,
    },
    actions: [
        {
            name: "load_discovery",
            description:
                "Replace the proposal review's discovered runnable services. All services default to included; .NET services default to Service Defaults.",
            inputSchema: {
                type: "object",
                additionalProperties: false,
                properties: {
                    ...APPHOST_PATH_SCHEMA,
                    repoName: { type: "string" },
                    apphostStyle: {
                        type: "string",
                        enum: ["csharp-sdk", "csharp-file", "typescript"],
                    },
                    services: { type: "array", items: SERVICE_SCHEMA },
                },
                required: ["services", "apphostStyle"],
            },
            handler: (context) => {
                const domainId = domainIdForContext(context);
                clearScanTimer(domainId);
                const snapshot = updateSnapshot(domainId, (state) => {
                    state.repoName = String(context.input.repoName ?? state.repoName).trim();
                    if (APPHOST_STYLES.has(context.input.apphostStyle)) {
                        state.apphostStyle = context.input.apphostStyle;
                    }
                    state.scanStatus = "complete";
                    state.scanError = "";
                    state.discoveryLoaded = true;
                    state.proposalLoaded = false;
                    state.services = context.input.services.map(normalizeService);
                    state.confirmed = false;
                    state.proposalStale = state.proposal.resources.length > 0;
                });
                return { ok: true, serviceCount: snapshot.services.length };
            },
        },
        {
            name: "set_proposal",
            description:
                "Set the AppHost plan resources and connections while preserving user-added graph items.",
            inputSchema: {
                type: "object",
                additionalProperties: false,
                properties: {
                    ...APPHOST_PATH_SCHEMA,
                    resources: {
                        type: "array",
                        items: {
                            type: "object",
                            additionalProperties: false,
                            properties: {
                                id: { type: "string" },
                                name: { type: "string" },
                                type: {
                                    type: "string",
                                    description:
                                        "Aspire resource kind, such as .NET project, Next.js, Postgres, Redis, or Container.",
                                },
                                serviceId: { type: "string" },
                                detail: { type: "string" },
                                include: { type: "boolean" },
                            },
                            required: ["id", "name", "type"],
                        },
                    },
                    edges: {
                        type: "array",
                        items: {
                            type: "object",
                            additionalProperties: false,
                            properties: {
                                from: {
                                    type: "string",
                                    description:
                                        "Relationship subject and arrow origin. This resource references, waits for, or is a child of the target.",
                                },
                                to: {
                                    type: "string",
                                    description:
                                        "Relationship target and arrow destination. The arrowhead points to this resource.",
                                },
                                kind: {
                                    type: "string",
                                    enum: ["reference", "waitFor", "parent"],
                                    description:
                                        "Directed relationship: from references to, from waits for to, or from is a child of to.",
                                },
                                id: { type: "string" },
                            },
                            required: ["from", "to", "kind"],
                        },
                    },
                },
            },
            handler: (context) => {
                const domainId = domainIdForContext(context);
                const snapshot = updateSnapshot(domainId, (state) => {
                    const preservedResources = state.proposal.resources.filter(
                        (resource) => resource.userAdded,
                    );
                    const previousGenerated = state.proposal.resources.filter(
                        (resource) => !resource.userAdded,
                    );
                    const generatedNameOverrides = new Map();
                    const generatedResources = Array.isArray(context.input.resources)
                        ? context.input.resources.map((resource, index) => {
                              const generated = normalizeProposalResource(resource, index);
                              if (!generated.serviceId) {
                                  const linkedService = state.services.find(
                                      (service) =>
                                          service.id === generated.id ||
                                          service.resourceName.toLowerCase() ===
                                              generated.name.toLowerCase(),
                                  );
                                  generated.serviceId = linkedService?.id ?? "";
                              }
                              const existing = previousGenerated.find(
                                  (candidate) =>
                                      (generated.serviceId &&
                                          candidate.serviceId === generated.serviceId) ||
                                      candidate.id === generated.id,
                              );
                              if (existing?.userEdited) {
                                  generatedNameOverrides.set(generated.name, existing.name);
                                  return {
                                        ...generated,
                                        name: existing.name,
                                        type: existing.type,
                                        detail: existing.detail,
                                        include: existing.include,
                                        userEdited: true,
                                  };
                              }
                              return generated;
                          })
                        : previousGenerated;
                    const generatedKeys = new Set(
                        generatedResources.flatMap((resource) => [
                            `id:${resource.id}`,
                            `name:${resource.name.toLowerCase()}`,
                        ]),
                    );
                    const resources = [
                        ...generatedResources,
                        ...preservedResources.filter(
                            (resource) =>
                                !generatedKeys.has(`id:${resource.id}`) &&
                                !generatedKeys.has(`name:${resource.name.toLowerCase()}`),
                        ),
                    ];
                    const resourceNames = new Set(resources.map((resource) => resource.name));
                    const preservedEdges = state.proposal.edges.filter(
                        (edge) =>
                            (edge.userAdded || edge.userEdited) &&
                            resourceNames.has(edge.from) &&
                            resourceNames.has(edge.to),
                    );
                    const generatedEdges = Array.isArray(context.input.edges)
                        ? context.input.edges.map((edge, index) =>
                              normalizeProposalEdge(
                                  {
                                      ...edge,
                                      from: generatedNameOverrides.get(edge.from) ?? edge.from,
                                      to: generatedNameOverrides.get(edge.to) ?? edge.to,
                                  },
                                  index,
                              ),
                          )
                        : state.proposal.edges.filter((edge) => !edge.userAdded && !edge.userEdited);
                    const edgeKeys = new Set(
                        generatedEdges.map((edge) => `${edge.from}|${edge.kind}|${edge.to}`),
                    );
                    const generatedEdgeIds = new Set(generatedEdges.map((edge) => edge.id));
                    state.proposal = {
                        resources,
                        edges: [
                            ...generatedEdges,
                            ...preservedEdges.filter(
                                (edge) =>
                                    !generatedEdgeIds.has(edge.id) &&
                                    !edgeKeys.has(`${edge.from}|${edge.kind}|${edge.to}`),
                            ),
                        ],
                    };
                    state.proposalLoaded = true;
                    state.proposalEdited =
                        state.proposal.resources.some(
                            (resource) => resource.userAdded || resource.userEdited,
                        ) ||
                        state.proposal.edges.some((edge) => edge.userAdded || edge.userEdited);
                    state.proposalStale = false;
                    state.confirmed = false;
                });
                return { ok: true, resourceCount: snapshot.proposal.resources.length };
            },
        },
        {
            name: "get_confirmation",
            description:
                "Read the user's confirmed choices before editing the AppHost. Returns final service selections and the edited proposal graph.",
            inputSchema: {
                type: "object",
                additionalProperties: false,
                properties: APPHOST_PATH_SCHEMA,
            },
            handler: (context) => {
                const snapshot = getSnapshot(domainIdForContext(context));
                const proposal = confirmedProposal(snapshot.proposal);
                return {
                    confirmed: snapshot.confirmed,
                    scanStatus: snapshot.scanStatus,
                    scanError: snapshot.scanError,
                    discoveryLoaded: snapshot.discoveryLoaded,
                    proposalLoaded: snapshot.proposalLoaded,
                    apphostStyle: snapshot.apphostStyle,
                    included: snapshot.services.filter((service) => service.include),
                    excluded: snapshot.services
                        .filter((service) => !service.include)
                        .map(({ id, name, type }) => ({ id, name, type })),
                    serviceDefaults: snapshot.services
                        .filter((service) => service.include && service.serviceDefaults)
                        .map((service) => service.resourceName),
                    proposal,
                };
            },
        },
    ],
    open: async (context) => {
        const domainId = domainIdFrom(context.input);
        let entry = instances.get(context.instanceId);
        if (!entry) {
            entry = await startServer(context.instanceId, domainId);
        } else if (entry.domainId !== domainId) {
            entry.domainId = domainId;
        }
        const snapshot = getSnapshot(domainId);
        return {
            title: snapshot.repoName ? `Aspireify - ${snapshot.repoName}` : "Aspireify",
            status: snapshot.confirmed
                ? "Confirmed"
                : snapshot.scanStatus === "scanning"
                  ? "Scanning"
                  : snapshot.discoveryLoaded
                  ? `${snapshot.services.length} service${snapshot.services.length === 1 ? "" : "s"}`
                  : "Ready to scan",
            url: entry.url,
        };
    },
    onClose: async (context) => {
        const entry = instances.get(context.instanceId);
        if (!entry) {
            return;
        }
        instances.delete(context.instanceId);
        for (const client of entry.clients) {
            client.end();
        }
        await new Promise((resolveClose) => entry.server.close(resolveClose));
    },
});

const openAspireifyTool = {
    name: "open_aspireify",
    description:
        "Open or focus the Aspireify AppHost plan review before the skill edits any files.",
    parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
            ...APPHOST_PATH_SCHEMA,
            instanceId: {
                type: "string",
                description: `Stable panel handle; defaults to '${DEFAULT_INSTANCE_ID}'.`,
            },
        },
    },
    handler: async (arguments_) => {
        const instanceId = String(arguments_?.instanceId ?? "").trim() || DEFAULT_INSTANCE_ID;
        if (typeof sessionRef?.rpc?.canvas?.open !== "function") {
            return {
                textResultForLlm: "The canvas host is not available.",
                resultType: "failure",
            };
        }
        try {
            await sessionRef.rpc.canvas.open({
                canvasId: CANVAS_ID,
                instanceId,
                input: arguments_?.appHostPath ? { appHostPath: arguments_.appHostPath } : {},
            });
            return `Opened the Aspireify AppHost plan review (instance '${instanceId}').`;
        } catch (error) {
            return {
                textResultForLlm: `Failed to open the Aspireify canvas: ${error?.message ?? error}`,
                resultType: "failure",
            };
        }
    },
};

const GUIDANCE =
    "The Aspireify canvas is the confirmation boundary for the Propose phase: present one editable dependency graph and confirm with the user. " +
    "It opens automatically when the aspireify skill is invoked. The skill owns scanning, proposal logic, AppHost edits, " +
    "and validation. During Propose, call load_discovery with the detected AppHost style and each runnable " +
    "service's name/type/framework/exposesHttp/path, " +
    "call set_proposal with the resource graph, and call get_confirmation before editing. " +
    "Treat [aspireify canvas: ...] messages as user-initiated aspireify requests. Never re-implement discovery in the canvas.";

function isAspireifySkillInvocation(input) {
    const toolName = String(input?.toolName ?? "").toLowerCase();
    const leafName = toolName.split(/[.:/]/).at(-1);
    const skillName =
        input?.toolArgs && typeof input.toolArgs === "object"
            ? String(input.toolArgs.skill ?? "").toLowerCase()
            : "";
    return leafName === "skill" && skillName === "aspireify";
}

async function onPostToolUse(input) {
    if (!isAspireifySkillInvocation(input)) {
        return undefined;
    }
    if (typeof sessionRef?.rpc?.canvas?.open !== "function") {
        return {
            additionalContext:
                "The Aspireify skill is active, but the canvas host is unavailable. Present and confirm the proposal in chat.",
        };
    }
    try {
        await sessionRef.rpc.canvas.open({
            canvasId: CANVAS_ID,
            instanceId: DEFAULT_INSTANCE_ID,
            input: {},
        });
        return {
            additionalContext:
                "The Aspireify skill is active and its proposal review canvas is open. Populate it with load_discovery and set_proposal, then call get_confirmation before editing.",
        };
    } catch (error) {
        return {
            additionalContext: `The Aspireify skill is active, but its canvas could not be opened automatically: ${error?.message ?? error}. Call open_aspireify before presenting the proposal.`,
        };
    }
}

sessionRef = await joinSession({
    canvases: [aspireifyCanvas],
    tools: [openAspireifyTool],
    hooks: {
        onSessionStart: async () => ({ additionalContext: GUIDANCE }),
        onPostToolUse,
    },
});
